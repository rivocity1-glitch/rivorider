export default function Home() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center gap-4">
      <h1 className="text-4xl font-bold">OnBaro Customer App</h1>
      <p>This is light mode</p>
      <button
        onClick={() => {
          document.documentElement.classList.toggle('dark');
        }}
        className="bg-blue-600 text-white px-4 py-2 rounded"
      >
        Toggle Dark Mode
      </button>
    </div>
  );
}